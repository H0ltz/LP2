﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string exibicao = "";
        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] produtos = new int[4, 4];
            string auxiliar = "";
            int i, j;
            int soma = 0;
            int total = 0;

            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 4; j++)
                {
                Loop:;
                    auxiliar = Interaction.InputBox("Digite a quantidade do produto", "Entrada de dados");
                    if (string.IsNullOrEmpty(auxiliar))
                    {
                        MessageBox.Show("Digite um dado valido!");
                        goto Loop;
                    }
                    else
                    {
                        if (!int.TryParse(auxiliar, out produtos[j, i]))
                        {
                            MessageBox.Show("Dados Invalidos!");
                            i--;
                            goto Loop;
                        }

                    }
                    exibicao = $"Total Entradas do Produto {i + 1} Semana {j + 1} - {produtos[j, i]}\n";
                    total += produtos[j, i];
                    listboxDados.Items.Add(exibicao);

                }
                soma = 0;
                for(j = 0; j< 4; j++)
                {
                    
                    soma += produtos[j, i];
                }

                listboxDados.Items.Add($"Total Entradas do Produto {i+1}: {soma}");
            }
            listboxDados.Items.Add($"Total Geral Entradas: {total}");





        }

        private void listboxDados_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listboxDados.Items.Clear();
        }
    }
}
