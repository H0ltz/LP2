﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtnumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtnumero2, "");
                numero2 = Convert.ToDouble(txtnumero2.Text);
            }
            catch
            {
                errorProvider2.SetError(txtnumero2, "numero 2 inválido");
                txtnumero2.Focus();
            }
        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void btnmult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtresultado.Text = resultado.ToString();
        }

        private void btndiv_Click(object sender, EventArgs e)
        {
            if (numero2 != 0)
            {
                resultado = numero1 / numero2;
                txtresultado.Text = resultado.ToString();
            }
        }

        private void btnlimpar_Click(object sender, EventArgs e)
        {
            txtnumero1.Text = null;
            txtnumero2.Text = null;
            txtresultado.Text= null;
        }

        private void btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void txtnumero1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtnumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtnumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtnumero1, "Numero 1 inválido!");
                txtnumero1.Focus();
            }
            else
                errorProvider1.SetError(txtnumero1, "");
        }
    }
}
