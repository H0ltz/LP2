﻿using Pcontato0030482511019;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pcontato0030482511019
{
    internal class Contato
    {
        //ele ja entende que tem os atributos, aqui,, agora só vamos criar as propriedades direto
        //aqui n dá pra validar ou usar outras contas, ja vai ser fixo

        public int Idcontato { get; set; }
        public int Nomecontato { get; set; }

        public int Endcontato { get; set; }
        public int Cidadeidcidade { get; set; }

        public int Celcontato { get; set; }

        public int Emailcontato { get; set; }

        public DateTime Dtcadastrocontato { get; set; }


        public DataTable Listar()
        {
            SqlDataAdapter daContato;

            DataTable dtContato = new DataTable();

            try
            {
                daContato = new SqlDataAdapter("SELECT * FROM CIDADE ORDER BY NOME_CIDADE", frmPrincipal.conexao);
                daContato.Fill(dtContato);
                daContato.FillSchema(dtContato, SchemaType.Source);

            }
            catch (Exception)
            {
                throw;
            }
            return dtContato; //nao precisa adicionar ne excluir nada, só vai ler
        }

        public int Incluir() //INCLUSAO
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO CONTATO VALUES (@nomecontato,"+
                    "@endcontato,@cidadeidcidade,"+
                    "@celcontato,@emailcontato,@dtcadastrocontato",
                    frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nomecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@endcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidadeidcidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@emailcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato", SqlDbType.Date));



                mycommand.Parameters["@nomecontato"].Value = Nomecontato;

                mycommand.Parameters["@endcontato"].Value = Endcontato;

                mycommand.Parameters["@cidadeidcidade"].Value = Cidadeidcidade;

                mycommand.Parameters["@celcontato"].Value = Celcontato;

                mycommand.Parameters["@emailcontato"].Value = Emailcontato;

                mycommand.Parameters["@dtcadastrocontato"].Value = Dtcadastrocontato;

                retorno = mycommand.ExecuteNonQuery();


            }

            catch (Exception)
            {
                throw;
            }

            return retorno;
        }
        public int Alterar() //Alteraçãooooooo
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("UPDATE CONTATO SET NOME_CONTATO=@nomecontato," +
                    "END_CONTATO=@endcontato,"+ " CIDADE_ID_CIDADE=@cidadeidcidade," +
                    " CELL_CONTATO=@celcontato, EMAIL_CONTATO=@emailcontato, DTCADASTRO_CONTATO=@dtcadastrocontato WHERE ID_CONTATO = @idcontato",
                    frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@idcontato", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@nomecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@endcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidadeidcidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@emailcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato", SqlDbType.Date));



                mycommand.Parameters["@nomecontato"].Value = Nomecontato;

                mycommand.Parameters["@endcontato"].Value = Endcontato;

                mycommand.Parameters["@cidadeidcidade"].Value = Cidadeidcidade;

                mycommand.Parameters["@celcontato"].Value = Celcontato;

                mycommand.Parameters["@emailcontato"].Value = Emailcontato;

                mycommand.Parameters["@dtcadastrocontato"].Value = Dtcadastrocontato;

                retorno = mycommand.ExecuteNonQuery();


            }

            catch (Exception)
            {
                throw;
            }

            return retorno;
        }


    }

}

